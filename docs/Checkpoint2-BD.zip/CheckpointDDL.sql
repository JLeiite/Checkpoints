CREATE DATABASE segundoCheckpoint DEFAULT CHARACTER SET utf8mb4;
USE segundoCheckpoint;

CREATE TABLE TipoUsuario(
	idTipoUsuario INT PRIMARY KEY AUTO_INCREMENT,
    descricaoUsuario VARCHAR(45) NOT NULL
);

CREATE TABLE Endereco (
	idEndereco INT PRIMARY KEY AUTO_INCREMENT,
    CEP VARCHAR(8) NOT NULL,
    cidade VARCHAR(80) NOT NULL,
    estado VARCHAR (45) NOT NULL,
    pais VARCHAR (45) NOT NULL
);

CREATE TABLE Usuario (
	idUsuario INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(16) NOT NULL UNIQUE,
    data_nascimento DATE NOT NULL,
    email VARCHAR(255) NOT NULL,
    password VARCHAR (32) NOT NULL,
    create_time DATETIME NOT NULL, 
    telefone VARCHAR (45) NOT NULL,
    nome VARCHAR (45) NOT NULL,
    sobrenome VARCHAR (45) NOT NULL,
    idTipoUsuario INT NOT NULL,
    idEndereco INT NOT NULL,
    FOREIGN KEY (idTipoUsuario) REFERENCES TipoUsuario(idTipoUsuario),
    FOREIGN KEY (idEndereco) REFERENCES Endereco(idEndereco)
);

CREATE TABLE Estilo (
	idEstilo INT PRIMARY KEY AUTO_INCREMENT,
    estiloMusical VARCHAR (45) NOT NULL
);

CREATE TABLE Artista (
	idArtista INT PRIMARY KEY AUTO_INCREMENT, 
    idUsuarioArtista INT NOT NULL,
    idAgenciadorArtista INT,
    FOREIGN KEY (idUsuarioArtista) REFERENCES Usuario(idUsuario),
    FOREIGN KEY (idAgenciadorArtista) REFERENCES Usuario(idUsuario),
    cacheInicialArtista FLOAT,
    cacheFinalArtista FLOAT,
    porcentagemAgenciador FLOAT
);

CREATE TABLE ArtistaEstilo (
	idArtistaEstilo INT PRIMARY KEY AUTO_INCREMENT,
    idArtista INT,
    idEstilo INT,
    FOREIGN KEY (idArtista) REFERENCES Artista(idArtista),
    FOREIGN KEY (idEstilo) REFERENCES Estilo(idEstilo)
);

CREATE TABLE Banda (
	idBanda INT PRIMARY KEY AUTO_INCREMENT,
    nomeBanda VARCHAR(100) NOT NULL
);

CREATE TABLE ArtistaBanda (
	idArtistaBanda INT PRIMARY KEY AUTO_INCREMENT,
    idArtista INT NOT NULL,
    idBanda INT NOT NULL,
    FOREIGN KEY (idArtista) REFERENCES Artista(idArtista),
    FOREIGN KEY (idBanda) REFERENCES Banda(idBanda)
);

CREATE TABLE OcasiaoEvento (
	idOcasiao INT PRIMARY KEY AUTO_INCREMENT,
    tipoEvento VARCHAR(45) NOT NULL
);

CREATE TABLE Evento (
	idEvento INT PRIMARY KEY AUTO_INCREMENT,
    dataInicioEvento DATETIME NOT NULL,
    dataFinalEvento DATETIME NOT NULL,
    cacheArtista FLOAT NOT NULL,
    idOcasiao INT NOT NULL,
    idEndereco INT NOT NULL,
    FOREIGN KEY (idOcasiao) REFERENCES OcasiaoEvento(idOcasiao),
    FOREIGN KEY (idEndereco) REFERENCES Endereco(idEndereco),
    quantidadePublico INT NOT NULL,
    pagamento TINYINT NOT NULL, 
    idBanda INT,
    idArtista INT,
    FOREIGN KEY (idBanda) REFERENCES Banda(idBanda),
    FOREIGN KEY (idArtista) REFERENCES Artista(idArtista)
);

CREATE TABLE UsuarioEvento (
	idUsuarioEvento INT PRIMARY KEY AUTO_INCREMENT,
    idUsuario INT NOT NULL,
    idEvento INT NOT NULL,
    FOREIGN KEY (idUsuario) REFERENCES Usuario(idUsuario),
    FOREIGN KEY (idEvento) REFERENCES Evento(idEvento)
);