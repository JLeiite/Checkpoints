INSERT INTO TipoUsuario (descricaoUsuario) VALUES
('Artista'), 
('Contratante'), 
('Agenciador');

INSERT INTO Endereco (CEP, cidade, estado, pais) VALUES
('06460040', 'Barueri', 'São Paulo', 'Brasil'),
('01310300', 'São Paulo', 'São Paulo', 'Brasil'),
('88137086', 'Palhoça', 'Santa Catarina', 'Brasil'),
('54335035', 'Jaboatão dos Guararapes', 'Pernambuco', 'Brasil'),
('59064500', 'Natal', 'Rio Grande do Norte', 'Brasil'),
('69053575', 'Manaus', 'Amazonas', 'Brasil'),
('78790000', 'Itiquira', 'Mato Grosso', 'Brasil'),
('78557640', 'Sinop', 'Mato Grosso', 'Brasil'),
('69945000', 'Acrelândia', 'Acre', 'Brasil'),
('69919230', 'Rio Branco', 'Acre', 'Brasil'),
('37540000', 'Santa Rita do Sapucaí', 'Minas Gerais', 'Brasil'),
('12460000', 'Campos do Jordão', 'São Paulo', 'Brasil'),
('02012021', 'São Paulo', 'São Paulo', 'Brasil');

INSERT INTO Usuario (username, data_nascimento, email, password, create_time, telefone, nome, sobrenome, idTipoUsuario, idEndereco) VALUES
('zoesantello', '1996-09-07', 'zoe@santello.com', 'idk', '2022-09-03 00:00:00', '11 5051-5050', 'Zoe', 'Santello', 1, 1),
('albtorres', '1996-09-07', 'alb.torres@icloud.com', 'idk', '2022-09-03 00:00:00', '11 5052-2020', 'Alberto', 'Tôrres', 2, 2),
('bethany', '1996-09-07', 'bethany@mendes.com', 'idk', '2022-09-03 00:00:00', '11 5053-3030', 'Bethany', 'Mendes', 1, 3),
('fgomes', '1996-09-07', 'francis.gomes@gmail.com', 'idk', '2022-09-03 00:00:00', '11 5054-4040', 'Francisco', 'Gomes', 2, 4),
('jorge', '1996-09-07', 'jorge.avestruz@javez.com', 'idk', '2022-09-04 00:00:00', '11 5055-0000', 'Jorge', 'Avestruz', 1, 5),
('bmadureira', '1996-09-07', 'bmadureira@gmail.com', 'idk', '2022-09-04 00:00:00', '11 5056-6666', 'Bruna', 'Madureira', 3, 6),
('toshiba', '1996-09-07', 'andre.toshiba@toshiba.com', 'idk', '2022-09-04 00:00:00', '11 5057-7777', 'Andre', 'Toshiba', 1, 7),
('brendon', '1996-09-07', 'brendon_batista@gmail.com', 'idk', '2022-09-04 00:00:00', '11 5058-8080', 'Brendon', 'Batista', 3, 8),
('kbezerra', '1996-09-07', 'kbezerra@bezerra.com', 'idk', '2022-09-04 00:00:00', '11 5059-9999', 'Karoline', 'Bezerra', 1, 9),
('jordanguerra', '1996-09-07', 'jordan_guerra@icloud.com', 'idk', '2022-09-04 00:00:00', '11 5110-1010', 'Jordan', 'Guerra', 1, 10);

INSERT INTO Estilo (estiloMusical) VALUES
('Sertanejo'), ('Pop'), ('Rock'), ('MPB'), ('Gospel'), ('Jazz'), ('Pagode'), ('Samba'), ('Axé'),
('Eletrônica'), ('Funk'), ('RAP'), ('Indie'), ('Soul'), ('Outros');

INSERT INTO Artista (idUsuarioArtista, idAgenciadorArtista, cacheInicialArtista, cacheFinalArtista, porcentagemAgenciador) VALUES 
(1, NULL, 10000, 25000, NULL),
(3, NULL, 500, 1500, NULL),
(5, 6, 1000, 5000, 25),
(7, 8, 150000, 8000, 10),
(9, NULL, 150, 800, NULL),
(10, 6, 2500, 12000, 15);

INSERT INTO ArtistaEstilo (idArtista, idEstilo) VALUES
(1, 10),
(2, 1), (2, 2), (2, 4), (2, 7),
(3, 5), (3, 13),
(4, 3), (4, 11), (4, 12),
(5, 6), (5,14),
(6, 8), (6, 9);

INSERT INTO Banda (nomeBanda) VALUES
('BOL4'), ('Orbit');

INSERT INTO ArtistaBanda (idArtista, idBanda) VALUES
(2, 1), (5, 1),
(3, 2), (6, 2);

INSERT INTO OcasiaoEvento (tipoEvento) VALUES
('Festa, churrasco ou aniversario'),
('Bar, balada ou restaurante'),
('Casamento'),
('Evento público'),
('Evento de empresa privada'),
('Evento beneficente');

-- PAGAMENTO 0 -> ABERTO / 1 -> PAGO
INSERT INTO Evento (dataInicioEvento, dataFinalEvento, cacheArtista, idOcasiao, idEndereco, quantidadePublico, pagamento, idBanda, idArtista) VALUES
('2022-10-12 22:00', '2022-10-12 22:30', 22350, 4, 13, 2500, 1, NULL, 1),
('2022-10-05 19:00', '2022-10-05 21:30', 2000, 3, 12, 400, 1, 1, NULL),
('2022-10-21 23:00', '2022-10-22 00:30', 15100, 5, 11, 1200, 0, 2, NULL);

INSERT INTO UsuarioEvento (idUsuario, idEvento) VALUES
(1, 1), (2 ,1),
(3, 2), (9 ,2), (4 ,2),
(5, 3), (10 ,3), (2 ,3);

-- ATUALIZAR TABELA (Cidade -> ID 3)
-- UPDATE Endereco SET CEP = '88330900', cidade = 'Balneário Camboriú' WHERE idEndereco = 3;

-- DELETAR TABELA (Estilo -> ID 15)
-- DELETE FROM estilo WHERE idEstilo = 15;

-- SELECIONAR TODOS OS ESTILOS MUSICAIS
-- SELECT * FROM estilo WHERE estiloMusical LIKE '_o%';

-- SELECIONANDO TODOS OS EVENTOS DAS BANDAS
-- SELECT 
-- evento.idEvento,
-- evento.dataInicioEvento,
-- ocasiaoevento.tipoEvento,
-- endereco.cidade,
-- evento.quantidadePublico,
-- evento.cacheArtista,
-- banda.nomeBanda
-- FROM evento 
-- INNER JOIN ocasiaoevento ON evento.idOcasiao = ocasiaoevento.idOcasiao
-- INNER JOIN endereco ON evento.idEndereco = endereco.idEndereco
-- INNER JOIN banda ON evento.idBanda = banda.idBanda;