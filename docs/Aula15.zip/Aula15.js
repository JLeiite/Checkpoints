function criarConta(numeroConta, tipoConta, saldo, titularConta) {
    return{
        numeroConta,
        tipoConta,
        saldo,
        titularConta
    }
}

// Incluindo novas contas
let conta1 = criarConta('5486273622', 'Conta corrente', 27771, 'Abigael Natte');
let conta2 = criarConta('1183971869', 'Poupança', 8675,'Ramon Connell');
let conta3 = criarConta('9582019689', 'Poupança', 27363, 'Jarret Lafuente');
let conta4 = criarConta('1761924656', 'Poupança', 32415, 'Ansel Ardley');
let conta5 = criarConta('7401971607', 'Poupança', 18789, 'Jacki Shurmer');
let conta6 = criarConta('630841470', 'Conta corrente', 28776, 'Jobi Mawtus');
let conta7 = criarConta('4223508636', 'Conta corrente', 2177, 'Thomasin Latour');
let conta8 = criarConta('185979521', 'Poupança', 25994, 'Lonnie Verheijden');
let conta9 = criarConta('3151956165', 'Conta corrente', 7601, 'Alonso Wannan');
let conta10 = criarConta('2138105881', 'Poupança', 33196, 'Bendite Huggett'); 

// Solicitar valor de depósito ou saque
const readlineSync = require('readline-sync');

// Criando metodos para consulta de cliente, depósito e saque
const banco = {
    clientes: [conta1, conta2, conta3, conta4, conta5, conta6, conta7, conta8, conta9, conta10],

    // Consultar cliente
    consultarCliente(titularConta) {
        for(let i = 0; i < this.clientes.length; i++){
            if (this.clientes[i].titularConta == titularConta){
                return(this.clientes[i]);
            }
        };
    },

    // Metodo para depósito na conta
    deposito (titularConta, depositoParametro) {
        console.log(this.consultarCliente(titularConta));

        // Conferir se titular da conta é verdadeiro
        if (this.consultarCliente(titularConta) != undefined){
            depositoParametro = readlineSync.questionFloat("Digite o valor de deposito: ");

            // Incluindo o valor do depósito na conta
            for(let i = 0; i < this.clientes.length; i++){
                if (this.clientes[i].titularConta == titularConta){
                    return(this.clientes[i].saldo + depositoParametro);
                };
            };
        } else {console.log ("Titular da conta não identificado!")};
    },
    
    // Metodo para saque na conta
    saque (titularConta, saqueParametro) {
        console.log(this.consultarCliente(titularConta));

        // Conferir se titular da conta é verdadeiro
        if (this.consultarCliente(titularConta) != undefined){
            saqueParametro = readlineSync.questionFloat("Digite o valor de saque: ");

            // Incluindo o valor do saque na conta
            for(let i = 0; i < this.clientes.length; i++){
                if (this.clientes[i].titularConta == titularConta){
                    let saldoAtual = this.clientes[i].saldo - saqueParametro;
                    if (saldoAtual > 0){
                        return(console.log("Extração feita com sucesso, seu novo saldo: " + saldoAtual));
                    }
                    else{
                        return(console.log("Fundos insuficientes!"));
                    }
                }
            }
        } else {console.log ("Titular da conta não identificado!")};
    }
}

// CONSULTAR CLIENTE
console.log(banco.consultarCliente('Bendite Huggett'));

// EFETUAR DEPOSITO
console.log(banco.deposito('Bendite Huggett'));

// EFETUAR SAQUE
console.log(banco.saque('Ansel Ardley'));